import { combineReducers } from "redux";
import wallet from "./wallet.js";

export default combineReducers({
  wallet

});
